## Cloud Computing Mini Project 1

## Part 4: Developing a Hadoop program to analyze real logs (25 points)
## Group Members:

* Anthony Harris: AGH41@pitt.edu
* Haodong Xu: HAX31@pitt.edu
* Jane Sunyoung Lee:   SUJ20@pitt.edu
* Jose Zindia: jdz18@pitt.edu

NB: See Attached Data_Structure.zip file for source code 
   
  ``` 
	This program is modified based on WordCount porgram.
	It can run both on the server or on the local.
	If you want to run on the VM, you should pack the module as jar and upload it to the
	VM.
	Run main () in module Mapreduce01, the count result is in part-r-00000 in the output file.
	  
````
